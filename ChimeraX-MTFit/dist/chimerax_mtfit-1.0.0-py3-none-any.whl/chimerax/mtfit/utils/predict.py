#!/usr/bin/env python3
"""
Predict particle angles from template geometry.

This module provides a three-stage pipeline:
1. LCC filtering - Keep high-confidence template particles
2. Angle mapping - Transfer angles from template to input via spatial proximity
3. Filament snapping - Adjust outlier angles to filament median

@Builab 2025
"""

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from typing import Optional, Dict, Tuple

from .io import validate_dataframe

# Column name constants
COORD_COLUMNS = ["rlnCoordinateX", "rlnCoordinateY", "rlnCoordinateZ"]
ANGLE_COLUMNS = ["rlnAngleRot", "rlnAngleTilt", "rlnAnglePsi"]

# Default parameters
DEFAULT_LCC_KEEP_PERCENT = 80.0
DEFAULT_MAPPING_RADIUS = 100.0  # Angstroms
DEFAULT_MAX_NEIGHBORS = 8
DEFAULT_SNAP_MAX_DELTA = 20.0  # degrees
DEFAULT_MIN_FILAMENT_POINTS = 5

def normalize_angle(angle: float) -> float:
    """Normalize angle to range [-180, 180]."""
    return ((angle + 180) % 360) - 180

def circular_mean(angles: np.ndarray, weights: Optional[np.ndarray] = None) -> float:
    """
    Calculate circular mean of angles in degrees.
    
    Args:
        angles: Array of angles in degrees.
        weights: Optional weights for each angle.
    
    Returns:
        Circular mean in degrees (0-360).
    """
    angles_rad = np.deg2rad(angles)
    
    if weights is None:
        sin_mean = np.sin(angles_rad).mean()
        cos_mean = np.cos(angles_rad).mean()
    else:
        weights_norm = weights / (weights.sum() + 1e-12)
        sin_mean = (np.sin(angles_rad) * weights_norm).sum()
        cos_mean = (np.cos(angles_rad) * weights_norm).sum()
    
    mean_rad = np.arctan2(sin_mean, cos_mean)
    return (np.rad2deg(mean_rad) + 360.0) % 360.0


def circular_difference(angle1: float, angle2: float) -> float:
    """
    Calculate signed circular difference between two angles.
    
    Args:
        angle1: First angle in degrees.
        angle2: Second angle in degrees.
    
    Returns:
        Difference in degrees, wrapped to [-180, 180).
    """
    diff = angle1 - angle2
    return (diff + 180) % 360 - 180


def filter_by_lcc(
    df_input: pd.DataFrame,
    df_template: pd.DataFrame,
    angpix: float,
    neighbor_radius: float,
    keep_percentage: float = DEFAULT_LCC_KEEP_PERCENT
) -> pd.DataFrame:
    """
    Filter template particles by Local Cross-Correlation scores.
    
    For each tube in the input, identifies template particles within the
    neighborhood and retains only those with highest LCC scores.
    
    Algorithm:
    1. For each tube ID in input data
    2. Find all template particles within neighbor_radius of any input particle
    3. Sort template particles by LCC score (descending)
    4. Keep top keep_percentage of those particles
    
    Args:
        df_input: Input DataFrame with coordinates and tube IDs.
        df_template: Template DataFrame with coordinates, tube IDs, and LCC scores.
        angpix: Pixel size in Angstroms for coordinate conversion.
        neighbor_radius: Search radius in Angstroms.
        keep_percentage: Percentage of top LCC particles to retain (0-100).
    
    Returns:
        Filtered template DataFrame with only high-LCC particles.
    
    Raises:
        ValueError: If required columns are missing or parameters invalid.
    """
    # Validate inputs
    validate_dataframe(df_input, COORD_COLUMNS + ['rlnHelicalTubeID'])
    validate_dataframe(df_template, COORD_COLUMNS)
    
    has_lcc = 'rlnLCCmax' in df_template.columns
    	
    if not 0 < keep_percentage <= 100:
        raise ValueError(
            f"keep_percentage must be in (0, 100], got {keep_percentage}"
        )
    
    # Convert radius to pixel units
    radius_px = neighbor_radius / angpix
    
    print(f"\n{'='*60}")
    print("LCC FILTERING")
    print(f"{'='*60}")
    print(f"  Radius: {neighbor_radius:.1f} Å ({radius_px:.2f} px)")
    if has_lcc:
        print(f"  Keeping top {keep_percentage}% by LCC score")
    else:
        print(f"  ⚠ No rlnLCCmax column - keeping all neighbors")
            
    # Build spatial index for template particles
    template_coords = df_template[COORD_COLUMNS].to_numpy(dtype=float)
    kdtree = cKDTree(template_coords)
    
    # Process each tube
    tube_ids = df_input['rlnHelicalTubeID'].unique()
    print(f"  Processing {len(tube_ids)} tubes...")
    
    indices_to_keep = set()
    
    for tube_id in tube_ids:
        # Get input particles for this tube
        input_tube = df_input[df_input['rlnHelicalTubeID'] == tube_id]
        input_coords = input_tube[COORD_COLUMNS].to_numpy(dtype=float)
        
        # Find template particles within radius of any input particle
        neighbor_lists = kdtree.query_ball_point(input_coords, r=radius_px)
        
        # Collect unique neighbor indices
        neighbor_indices = set()
        for neighbors in neighbor_lists:
            neighbor_indices.update(neighbors)
        
        if not neighbor_indices:
            continue
        
        # Get neighbor particles and sort by LCC
        neighbor_mask = np.zeros(len(df_template), dtype=bool)
        neighbor_mask[list(neighbor_indices)] = True
        neighbors_df = df_template[neighbor_mask]
        
        if 'rlnLCCmax' in df_template.columns:
            # Keep top percentage by LCC score
            neighbors_sorted = neighbors_df.sort_values('rlnLCCmax', ascending=False)
            n_keep = max(1, int(np.ceil(len(neighbors_sorted) * keep_percentage / 100.0)))
            top_particles = neighbors_sorted.iloc[:n_keep]
        else:
            top_particles = neighbors_df
            
        indices_to_keep.update(top_particles.index)
    
    # Create filtered DataFrame
    df_filtered = df_template.loc[list(indices_to_keep)].copy()
    
    reduction = 100 * (1 - len(df_filtered) / len(df_template))
    print(f"  ✓ Filtered: {len(df_template)} → {len(df_filtered)} particles "
          f"({reduction:.1f}% reduction)")
    
    return df_filtered


def map_angles_from_template(
    df_input: pd.DataFrame,
    df_template: pd.DataFrame,
    angpix: float = 14.0,
    search_radius: float = DEFAULT_MAPPING_RADIUS,
    max_neighbors: int = DEFAULT_MAX_NEIGHBORS,
    weight_by_distance: bool = True
) -> pd.DataFrame:
    """
    Map angles from template to input particles based on spatial proximity.
    
    For each input particle:
    1. Find nearby template particles within search_radius
    2. Compute circular mean of their angles (optionally weighted by distance)
    3. Assign computed angles to input particle
    
    Args:
        df_input: Input DataFrame with coordinates.
        df_template: Template DataFrame with coordinates and angles.
        angpix: Pixel size in Angstroms.
        search_radius: Search radius in Angstroms.
        max_neighbors: Maximum number of neighbors to consider.
        weight_by_distance: Whether to weight angles by inverse distance.
    
    Returns:
        Input DataFrame with mapped angles.
    
    Raises:
        ValueError: If required columns are missing.
    """
    # Validate columns
    validate_dataframe(df_input, COORD_COLUMNS)
    validate_dataframe(df_template, COORD_COLUMNS + ANGLE_COLUMNS)
    
    print(f"\n{'='*60}")
    print("ANGLE MAPPING")
    print(f"{'='*60}")
    print(f"  Search radius: {search_radius:.1f} Å")
    print(f"  Max neighbors: {max_neighbors}")
    print(f"  Distance weighting: {'enabled' if weight_by_distance else 'disabled'}")
    
    # Extract coordinates
    input_coords = df_input[COORD_COLUMNS].to_numpy(dtype=float)
    template_coords = df_template[COORD_COLUMNS].to_numpy(dtype=float)
    radius_px = search_radius / angpix
    
    # Initialize output with angles
    df_output = df_input.copy()
    for angle_col in ANGLE_COLUMNS:
        df_output[angle_col] = 0.0
    
    fallback_counts = {col: 0 for col in ANGLE_COLUMNS}
    
    # Process each input particle
    for i, particle_coord in enumerate(input_coords):
        # Calculate distances to all template particles
        distances = np.linalg.norm(template_coords - particle_coord, axis=1)
        neighbor_order = np.argsort(distances)
        
        # Get k nearest neighbors
        nearest_k = neighbor_order[:max(1, max_neighbors)]
        neighbor_distances = distances[nearest_k]
        
        # Check which neighbors are within radius
        within_radius = neighbor_distances <= radius_px
        
        if not np.any(within_radius):
            # No neighbors in radius - use closest one as fallback
            within_radius = np.zeros_like(neighbor_distances, dtype=bool)
            within_radius[0] = True
            used_fallback = True
        else:
            used_fallback = False
        
        # Select neighbors to use
        selected_neighbors = nearest_k[within_radius]
        selected_distances = neighbor_distances[within_radius]
        
        # Compute distance weights if requested
        if weight_by_distance and len(selected_distances) > 1:
            weights = 1.0 / (selected_distances + 1e-9)
        else:
            weights = None
        
        # Map each angle using circular mean
        for angle_col in ANGLE_COLUMNS:
            template_angles = df_template[angle_col].iloc[selected_neighbors].to_numpy(dtype=float)
            mapped_angle = circular_mean(template_angles, weights)
            df_output.at[i, angle_col] = mapped_angle
            
            if used_fallback:
                fallback_counts[angle_col] += 1
    
    # Report fallback usage
    if any(count > 0 for count in fallback_counts.values()):
        total_fallbacks = fallback_counts[ANGLE_COLUMNS[0]]
        print(f"  ⚠ {total_fallbacks} particles required fallback "
              f"(no neighbors within radius)")
    
    print(f"  ✓ Mapped angles to {len(df_output)} particles")
    
    return df_output


def snap_angles_to_filament_median(
    df: pd.DataFrame,
    max_delta: float = DEFAULT_SNAP_MAX_DELTA,
    min_points: int = DEFAULT_MIN_FILAMENT_POINTS
) -> pd.DataFrame:
    """
    Adjust outlier angles to filament median values.
    
    For each filament (tube):
    1. Calculate circular median for each angle
    2. Identify particles with angles > max_delta from median
    3. Snap those outliers to the median value
    
    Args:
        df: DataFrame with particles, angles, and tube IDs.
        max_delta: Maximum angular deviation in degrees before snapping.
        min_points: Minimum points required per filament for snapping.
    
    Returns:
        DataFrame with adjusted angles.
    """
    if 'rlnHelicalTubeID' not in df.columns:
        print("[Snap] No rlnHelicalTubeID column; treating all as one filament")
        df = df.copy()
        df['rlnHelicalTubeID'] = 1
    
    print(f"\n{'='*60}")
    print("FILAMENT ANGLE SNAPPING")
    print(f"{'='*60}")
    print(f"  Max deviation: {max_delta}°")
    print(f"  Min points per filament: {min_points}")
    
    df_output = df.copy()
    snap_counts = {col: 0 for col in ANGLE_COLUMNS}
    
    # Process each filament
    for tube_id, tube_group in df_output.groupby('rlnHelicalTubeID'):
        if len(tube_group) < min_points:
            continue
        
        # Process each angle column
        for angle_col in ANGLE_COLUMNS:
            angles = tube_group[angle_col].to_numpy(dtype=float)
            
            # Calculate median using circular mean
            median_angle = circular_mean(angles)
            
            # Find outliers
            deviations = np.abs([
                circular_difference(angle, median_angle) for angle in angles
            ])
            outlier_mask = deviations > max_delta
            
            # Snap outliers to median
            if np.any(outlier_mask):
                outlier_indices = tube_group.index[outlier_mask]
                df_output.loc[outlier_indices, angle_col] = median_angle
                snap_counts[angle_col] += int(outlier_mask.sum())
    
    # Report results
    total_snapped = sum(snap_counts.values())
    if total_snapped > 0:
        print(f"  ✓ Snapped {total_snapped} angles across all filaments")
        for angle_col, count in snap_counts.items():
            if count > 0:
                print(f"    - {angle_col}: {count}")
    else:
        print(f"  ✓ No outliers detected")
    
    return df_output

def fit_polynomial(x, y, order=2):
    """
    Fit polynomial to data.
    
    Returns:
        Tuple of (fitted_y, residuals, rmse, poly_object)
    """
    # Ensure there is enough data for fitting (at least order + 1 points)
    if len(x) <= order:
        return np.full_like(y, np.nan), np.full_like(y, np.nan), np.nan, None

    coeffs = np.polyfit(x, y, order)
    poly = np.poly1d(coeffs)
    fitted_y = poly(x)
    residuals = y - fitted_y
    rmse = np.sqrt(np.mean(residuals**2))
    return fitted_y, residuals, rmse, poly


def robust_mad_outlier_detection(residuals, threshold=3.5):
    """
    Detects outliers using the Modified Z-score based on the Median Absolute Deviation (MAD).
    """
    if len(residuals) < 5: 
        return np.zeros_like(residuals, dtype=bool)

    median_residual = np.median(residuals)
    mad = np.median(np.abs(residuals - median_residual))
    
    if mad == 0:
        return np.abs(residuals - median_residual) > 1e-6 

    # 0.6745 is the correction factor for consistency with Gaussian Z-score
    modified_z_score = 0.6745 * (residuals - median_residual) / mad
    
    is_outlier = np.abs(modified_z_score) > threshold
    return is_outlier


def iterative_fit_and_detect(particle_indices, angles, order=2, n_iterations=2):
    """
    Performs iterative polynomial fitting and MAD outlier detection (2 steps).
    
    Returns:
        Tuple: (final_fitted_angles, total_outliers_mask)
    """
    
    N = len(angles)
    total_outliers_mask = np.zeros(N, dtype=bool)
    current_inlier_indices = np.arange(N)
    
    final_fitted_angles = np.full(N, np.nan)
    final_rmse = np.nan
    final_poly = None
    
    for i in range(n_iterations):
        
        # 1. Get current inlier data
        x_in = particle_indices[current_inlier_indices]
        y_in = angles[current_inlier_indices]
        
        # Skip if not enough data remains
        if len(x_in) <= order:
            break
            
        # 2. Fit polynomial to inliers and get the poly object
        _, _, _, poly = fit_polynomial(x_in, y_in, order)
        
        # 3. Calculate fitted line and residuals for ALL original points
        fitted_angles_all = poly(particle_indices)
        residuals_all = angles - fitted_angles_all
        
        # 4. Detect outliers among the current inliers
        residuals_for_detection = residuals_all[current_inlier_indices]
        is_outlier_in_subset = robust_mad_outlier_detection(residuals_for_detection)
        
        # 5. Map detected outliers back to the original index space
        outlier_indices_original = current_inlier_indices[is_outlier_in_subset]
        
        # 6. Break if no new outliers found
        if len(outlier_indices_original) == 0:
            final_fitted_angles = fitted_angles_all
            final_poly = poly
            final_rmse = np.sqrt(np.mean((angles[~total_outliers_mask] - fitted_angles_all[~total_outliers_mask])**2))
            break
            
        # 7. Update the total outlier mask
        total_outliers_mask[outlier_indices_original] = True
        
        # 8. Update the current inlier indices for the next iteration
        current_inlier_indices = np.where(~total_outliers_mask)[0]
        
        # 9. Record final results if this is the last iteration
        if i == n_iterations - 1:
            final_fitted_angles = fitted_angles_all
            final_poly = poly
            final_rmse = np.sqrt(np.mean((angles[~total_outliers_mask] - fitted_angles_all[~total_outliers_mask])**2))

    # Return only the essential items for correction
    return total_outliers_mask, final_poly


def smooth_angles(df):
    """
    Reads star df, performs iterative angle correction, and returns the corrected df.
    Prints the total number of detected and corrected outlier particles.
    """    
    df_corrected = df.copy()
    grouped = df.groupby('rlnHelicalTubeID')
    
    angle_names = ['rlnAngleRot', 'rlnAngleTilt', 'rlnAnglePsi']
    
    # Initialize counter
    total_outliers_corrected = 0 

    # --- Iterative Correction Loop ---
    for tube_id, tube_data in grouped:
        particle_indices = np.arange(len(tube_data))
        tube_masks = {}
        tube_polys = {}
        
        # 1. Run iterative fit and detection for all three angles
        for angle_col in angle_names:
            angles = tube_data[angle_col].values
            
            # Get the mask and polynomial object
            total_outliers_mask, final_poly = \
                iterative_fit_and_detect(particle_indices, angles, order=2, n_iterations=2)
            
            tube_masks[angle_col] = total_outliers_mask
            tube_polys[angle_col] = final_poly

        # 2. Global Outlier Identification (Flag if outlier in ANY angle)
        global_outlier_mask = np.zeros(len(tube_data), dtype=bool)
        for angle in angle_names:
             global_outlier_mask = global_outlier_mask | tube_masks[angle]

        # 3. Extrapolation and Data Replacement
        if global_outlier_mask.any():
            # Count outliers for this tube and add to total
            outlier_count = global_outlier_mask.sum()
            total_outliers_corrected += outlier_count
            
            indices_in_tube = tube_data.index
            outlier_indices_original_df = indices_in_tube[global_outlier_mask]
            outlier_indices_local = particle_indices[global_outlier_mask]
            
            for angle in angle_names:
                poly = tube_polys[angle]
                # Calculate new (extrapolated) values using the final robust fit
                extrapolated_values = poly(outlier_indices_local)
                
                # Replace the values in the corrected DataFrame copy
                df_corrected.loc[outlier_indices_original_df, angle] = extrapolated_values
	
    # Print summary
    print(f"  Total outlier found and corrected: {total_outliers_corrected}")
    
    return df_corrected


def smooth_rot_angle(
    df: pd.DataFrame,
    smoothing_factor: float = 0.5,
    window: int = 5,
) -> pd.DataFrame:
    """
    Locally smooth rlnAngleRot along each tube.

    Unlike smooth_angles(), which only replaces particles flagged as
    statistical outliers, this blends every particle's Rot angle with the
    circular mean of a sliding window of its neighbors along the tube
    (picking order). `smoothing_factor` controls the blend: 0 leaves angles
    untouched, 1 fully replaces them with the local window average. Useful
    for residual wobble that isn't extreme enough to be flagged as an
    outlier, e.g. right at a Connect join.

    Args:
        df: DataFrame with rlnHelicalTubeID and rlnAngleRot columns.
        smoothing_factor: Blend weight for the local average, 0-1.
        window: Number of neighboring particles (centered) to average over.

    Returns:
        DataFrame with rlnAngleRot smoothed.
    """
    if not 0.0 <= smoothing_factor <= 1.0:
        raise ValueError("smoothing_factor must be between 0 and 1")
    if 'rlnHelicalTubeID' not in df.columns:
        raise ValueError("rlnHelicalTubeID column required for Rot smoothing")
    if 'rlnAngleRot' not in df.columns:
        raise ValueError("rlnAngleRot column required for Rot smoothing")
    if window < 1:
        raise ValueError("window must be at least 1")

    df_out = df.copy()
    half = window // 2

    for tube_id, group in df_out.groupby('rlnHelicalTubeID'):
        idx = group.index
        angles = group['rlnAngleRot'].to_numpy(dtype=float)
        n = len(angles)
        blended = np.empty(n)

        for i in range(n):
            lo = max(0, i - half)
            hi = min(n, i + half + 1)
            local_mean = circular_mean(angles[lo:hi])
            blended[i] = circular_mean(
                np.array([angles[i], local_mean]),
                weights=np.array([1.0 - smoothing_factor, smoothing_factor])
            )

        df_out.loc[idx, 'rlnAngleRot'] = normalize_angle(blended)

    return df_out


def _tilt_psi_to_unit_vector(tilt: np.ndarray, psi: np.ndarray) -> np.ndarray:
    """
    Reconstruct the direction a particle's long/symmetry axis points in the
    tomogram frame, from genuine RELION-convention Euler angles Tilt/Psi.

    Verified numerically against ArtiaX's own RELIONEulerRotation (the code
    that actually renders these angles in 3D): the matrix
    Rz(-psi)*Ry(-tilt)*Rz(-rot) applied to the reference Z-axis (0,0,1) gives
    forward = (-sin(tilt)cos(psi), sin(tilt)sin(psi), cos(tilt)) -- Rot drops
    out entirely (confirmed by direct numerical test: forward is identical
    across Rot=0/30/90/180 for fixed Tilt/Psi). That's consistent with Rot
    being the roll around the particle's own axis (why Twist targets it) and
    Tilt/Psi being what determines which way that axis actually points.

    This is the correct convention for angles from genuine 3D orientation
    search (e.g. the raw template-matching picks) -- NOT the same thing as
    fit.py's resample(), which fabricates its own Tilt/Psi from pure
    coordinate-tangent geometry and does not follow this convention (an
    earlier version of this function mixed the two up).
    """
    tilt_rad = np.radians(tilt)
    psi_rad = np.radians(psi)
    x = -np.sin(tilt_rad) * np.cos(psi_rad)
    y = np.sin(tilt_rad) * np.sin(psi_rad)
    z = np.cos(tilt_rad)
    return np.column_stack([x, y, z])


def compute_polarity_flips(
    df_reference: pd.DataFrame,
    df_predicted: pd.DataFrame,
) -> Dict[int, int]:
    """
    For each tube, determine whether df_reference's own row order runs the same
    direction as df_predicted's Tilt/Psi-encoded long-axis orientation, or the
    opposite.

    df_reference and df_predicted must contain the same particles (same index)
    for each tube. df_predicted's rlnAngleTilt/rlnAnglePsi are expected to come
    from genuine template matching (see _tilt_psi_to_unit_vector) -- mapping
    from fit.py's own synthetic tangent-derived angles here would compare a
    made-up convention against itself and tell you nothing.

    Returns a dict mapping tube_id -> +1 (row order already agrees with the
    predicted direction) or -1 (row order runs opposite to it -- a per-tube
    twist increment should be negated to stay consistently handed relative to
    every tube's real polarity, not just self-consistent within each tube).
    """
    flips: Dict[int, int] = {}
    for tube_id, ref_group in df_reference.groupby('rlnHelicalTubeID'):
        coords = ref_group[COORD_COLUMNS].to_numpy(dtype=float)
        if len(coords) < 2:
            flips[tube_id] = 1
            continue

        row_order_dir = coords[-1] - coords[0]
        norm = np.linalg.norm(row_order_dir)
        if norm == 0:
            flips[tube_id] = 1
            continue
        row_order_dir = row_order_dir / norm

        pred_group = df_predicted.loc[ref_group.index]
        vectors = _tilt_psi_to_unit_vector(
            pred_group['rlnAngleTilt'].to_numpy(dtype=float),
            pred_group['rlnAnglePsi'].to_numpy(dtype=float),
        )
        mean_dir = vectors.mean(axis=0)
        mean_norm = np.linalg.norm(mean_dir)
        if mean_norm == 0:
            flips[tube_id] = 1
            continue
        mean_dir = mean_dir / mean_norm

        flips[tube_id] = 1 if np.dot(row_order_dir, mean_dir) >= 0 else -1

    return flips


def assign_twist_angles(
    df: pd.DataFrame,
    twist_angle: float,
    polarity_flips: Optional[Dict[int, int]] = None,
) -> pd.DataFrame:
    """
    Add a fixed angular increment per particle along each tube to the existing rlnAngleRot.

    rlnAnglePsi/rlnAngleTilt encode the filament's actual local tangent direction
    (see fit.py's resample(): Psi = tangent azimuth, Tilt = tangent elevation) --
    they describe where the tube physically points, not a roll around its own
    axis. rlnAngleRot, applied before Tilt/Psi in RELION's ZYZ convention, is the
    roll around the particle's own axis before it gets reoriented to point along
    the tangent -- that's the correct target for modeling real protofilament-to-
    protofilament twist. Incrementing Psi instead (an earlier version of this
    function did) rotates the apparent tube direction itself, and since the
    increment accumulates particle after particle, the misalignment from the
    true geometric path compounds down the tube, producing an increasingly
    curled/kinked result instead of a clean twist.

    Particles within each tube are ordered by projection onto the tube's principal axis
    (first PCA component). Particle i gets rlnAngleRot += i * twist_angle degrees, on top
    of whatever Rot was already assigned (e.g. by the predict step, from matched template
    particles' actual orientation). If rlnAngleRot is not present, it is initialized to 0
    before the twist increment is applied. Only rlnAngleRot is modified; other columns
    are left unchanged.

    PCA's principal axis has an inherent sign ambiguity (SVD can return either
    direction) with no connection to the tube's real biological polarity, so
    without correction two tubes with the same real-world orientation can get
    opposite ramp directions purely by numerical coincidence. To keep the
    ordering at least consistent tube-to-tube, the axis sign is anchored to
    match the tube's own existing row order (i.e. whatever consistent walk
    Fit/Connect/Predict's own resampling already established), rather than
    left to whatever SVD happens to return.

    That anchoring alone only guarantees self-consistency within each tube --
    not that the ramp is applied with the same real-world handedness across
    different tubes, since row order has no inherent connection to true
    plus/minus-end polarity either. If `polarity_flips` is given (see
    compute_polarity_flips(), typically derived from a genuine template-
    matched reference), each tube's increment is multiplied by its flip
    (+1 or -1) so the twist stays consistently handed relative to each
    tube's real polarity instead of just its arbitrary storage order.
    """
    if 'rlnHelicalTubeID' not in df.columns:
        raise ValueError("rlnHelicalTubeID column required for twist assignment")

    df_out = df.copy()
    if 'rlnAngleRot' not in df_out.columns:
        df_out['rlnAngleRot'] = 0.0

    print(f"\n{'='*60}")
    print("TWIST ANGLE ASSIGNMENT")
    print(f"{'='*60}")
    print(f"  Twist angle per particle: {twist_angle}°")

    tube_ids = df_out['rlnHelicalTubeID'].unique()
    for tube_id in tube_ids:
        mask = df_out['rlnHelicalTubeID'] == tube_id
        group = df_out[mask]
        coords = group[COORD_COLUMNS].to_numpy(dtype=float)

        if len(coords) > 1:
            centered = coords - coords.mean(axis=0)
            _, _, Vt = np.linalg.svd(centered, full_matrices=False)
            projections = centered @ Vt[0]
            # Anchor the arbitrary SVD sign to the tube's own existing row
            # order, so ramp direction doesn't flip randomly between tubes.
            if projections[-1] < projections[0]:
                projections = -projections
            order = np.argsort(projections)
        else:
            order = np.array([0])

        flip = polarity_flips.get(tube_id, 1) if polarity_flips else 1
        indices = group.index[order]
        increment = np.arange(len(indices)) * twist_angle * flip
        df_out.loc[indices, 'rlnAngleRot'] = normalize_angle(
            df_out.loc[indices, 'rlnAngleRot'].to_numpy(dtype=float) + increment
        )

    print(f"  ✓ Assigned twist angles to {len(tube_ids)} tubes, "
          f"{len(df_out)} particles total")
    return df_out


def predict_angles(
    df_input: pd.DataFrame,
    df_template: Optional[pd.DataFrame] = None,
    angpix: float = 14.0,
    neighbor_radius: float = 100.0,
    lcc_keep_percent: float = 80.0,
    snap_max_delta: float = 20.0,
    snap_min_points: int = 5,
    direction: int = 0,
    rot_smooth_factor: float = 0.0,
    rot_smooth_window: int = 5
) -> Tuple[pd.DataFrame, Dict[str, pd.DataFrame]]:
    
    df_working = df_input.copy()
    intermediates = {}

    # --- New: Direction Flip Logic ---
    if direction == 1:
        print("  Applying direction flip (180 - rlnAnglePsi)")
        # Normalize ensures the resulting angle stays in [-180, 180]
        df_working['rlnAnglePsi'] = df_working['rlnAnglePsi'].apply(lambda x: normalize_angle(x + 180))
        
        # Flip Tilt (Reverse direction along filament)
        # Note: Tilt is typically in range [0, 180]
        df_working['rlnAngleTilt'] = df_working['rlnAngleTilt'].apply(lambda x: 180.0 - x)

    # --- Step 1 & 2: Template Mapping (if available) ---
    if df_template is not None:
        df_filtered = filter_by_lcc(df_working, df_template, angpix, neighbor_radius, lcc_keep_percent)
        intermediates['filtered'] = df_filtered
        
        df_working = map_angles_from_template(df_working, df_filtered, angpix, neighbor_radius)
        intermediates['mapped'] = df_working

    # --- Step 3: Refinement & Smoothing ---
    df_final = snap_angles_to_filament_median(df_working, snap_max_delta, snap_min_points)
    
    # Final cleanup before smoothing
    df_final['rlnAnglePsi'] = normalize_angle(df_final['rlnAnglePsi'].values)
    df_final['rlnAngleRot'] = normalize_angle(df_final['rlnAngleRot'].values)
    
    df_corrected = smooth_angles(df_final) #

    if rot_smooth_factor > 0.0:
        df_corrected = smooth_rot_angle(df_corrected, rot_smooth_factor, rot_smooth_window)

    return df_corrected, intermediates